#include "Cache.h"

#include <algorithm>
#include <stdexcept>
#include <sstream>

Cache::Cache(std::size_t capacity_blocks,
             std::size_t ways,
             double hit_latency_ns,
             double miss_penalty_ns)
    : capacity_blocks_(capacity_blocks),
      ways_(ways),
      set_count_(0),
      hit_latency_ns_(hit_latency_ns),
      miss_penalty_ns_(miss_penalty_ns) {
    if (capacity_blocks_ == 0)
        throw std::invalid_argument("La capacidad debe ser mayor que cero.");
    if (ways_ == 0 || ways_ > capacity_blocks_)
        throw std::invalid_argument("El numero de vias debe estar entre 1 y la capacidad.");
    if (capacity_blocks_ % ways_ != 0)
        throw std::invalid_argument("La capacidad debe ser divisible por el numero de vias.");
    if (hit_latency_ns_ < 0.0 || miss_penalty_ns_ < 0.0)
        throw std::invalid_argument("Las latencias no pueden ser negativas.");

    set_count_ = capacity_blocks_ / ways_;
    sets_.resize(set_count_);
    lru_.resize(set_count_);
    for (std::size_t i = 0; i < set_count_; ++i)
        sets_[i].resize(ways_);
}

std::size_t Cache::set_index(std::uint64_t block_id) const {
    return static_cast<std::size_t>(block_id % set_count_);
}

void Cache::mark_recent(std::size_t set, std::uint64_t block_id) {
    std::list<std::uint64_t>& order = lru_[set];
    order.remove(block_id);
    order.push_front(block_id);
}

void Cache::access(std::uint64_t address) {
    // El programa recibe direcciones expresadas como identificadores de bloque.
    // Por tanto, cada número representa un bloque distinto de memoria.
    const std::uint64_t block_id = address;
    const std::size_t set = set_index(block_id);
    ++stats_.accesses;

    for (std::size_t way = 0; way < ways_; ++way) {
        if (sets_[set][way].valid && sets_[set][way].block_id == block_id) {
            ++stats_.hits;
            stats_.total_access_time_ns += hit_latency_ns_;
            mark_recent(set, block_id);
            return;
        }
    }

    ++stats_.misses;
    stats_.total_access_time_ns += hit_latency_ns_ + miss_penalty_ns_;

    // Primero se busca una vía libre.
    for (std::size_t way = 0; way < ways_; ++way) {
        if (!sets_[set][way].valid) {
            sets_[set][way].valid = true;
            sets_[set][way].block_id = block_id;
            mark_recent(set, block_id);
            return;
        }
    }

    // Si el conjunto está lleno, LRU expulsa el menos recientemente utilizado.
    const std::uint64_t victim = lru_[set].back();
    lru_[set].pop_back();
    ++stats_.replacements;

    for (std::size_t way = 0; way < ways_; ++way) {
        if (sets_[set][way].block_id == victim) {
            sets_[set][way].block_id = block_id;
            break;
        }
    }
    mark_recent(set, block_id);
}

const CacheStats& Cache::stats() const { return stats_; }
std::size_t Cache::capacity() const { return capacity_blocks_; }
std::size_t Cache::ways() const { return ways_; }
std::size_t Cache::sets() const { return set_count_; }

std::string Cache::configuration_name() const {
    std::ostringstream out;
    if (ways_ == 1) {
        out << "Correspondencia directa";
    } else if (ways_ == capacity_blocks_) {
        out << "Totalmente asociativa";
    } else {
        out << "Asociativa por conjuntos (" << ways_ << " vias)";
    }
    return out.str();
}
