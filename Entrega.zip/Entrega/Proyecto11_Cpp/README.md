# Proyecto 11 — Impacto de la Asociatividad en el Rendimiento de Caché

## Requisitos
- GNU/Linux (o un entorno con `g++`)
- Compilador GCC/G++ compatible con C++11 o superior

## Compilar
```bash
make
```

## Ejecutar patrones generados
```bash
./proyecto11 repetitiva
./proyecto11 ordenada
./proyecto11 aleatoria
```
Opcionalmente se puede indicar el CSV de salida:
```bash
./proyecto11 aleatoria resultados_aleatorios.csv
```

## Usar una secuencia desde archivo
Cada número representa un identificador de bloque (no una dirección de byte):
```bash
./proyecto11 --archivo datos/secuencia.txt resultados_archivo.csv
```
Ejemplo:
```bash
echo "0 8 16 24 0 8 16 24 1 9 17 25" > datos/secuencia.txt
./proyecto11 --archivo datos/secuencia.txt resultados_archivo.csv
```

## Qué compara
La caché mantiene una capacidad fija de 16 bloques. Se prueban:
- 1 vía: correspondencia directa.
- 2 vías: asociativa por conjuntos.
- 4 vías: asociativa por conjuntos.
- 8 vías: asociativa por conjuntos.
- 16 vías: totalmente asociativa.

Cada configuración recibe exactamente la misma secuencia. Se registran hits, misses, porcentajes, reemplazos y tiempo de acceso modelado.

## STL y LRU
- **STL**: se usan `vector` para conjuntos y líneas, `list` para mantener el orden de uso, y `string`/flujos de C++ para entrada y salida.
- **LRU**: cada conjunto mantiene una lista donde el bloque más reciente está al frente y el menos reciente al final. Si el conjunto está lleno, se reemplaza el último.

## Cómo interpretar el tiempo
Los valores predeterminados son una latencia de hit de 1 ns y una penalización adicional de miss de 50 ns. Es un modelo configurable de ejemplo, no una medición del tiempo físico de una CPU. El tiempo de ejecución del propio simulador es distinto del tiempo modelado de acceso a caché.

## Notas metodológicas
- La capacidad se expresa en bloques, no bytes.
- Los valores de entrada son identificadores de bloque, para mantener el ejemplo sencillo.
- La caché asociativa por conjuntos usa `conjunto = bloque_id % número_de_conjuntos`.
- La política LRU se aplica por conjunto.
- La secuencia aleatoria usa una semilla fija para reproducibilidad.
- El programa exporta resultados a CSV, que puede abrirse con LibreOffice Calc o Excel para elaborar gráficos.
