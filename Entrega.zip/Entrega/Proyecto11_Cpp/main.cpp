#include "Cache.h"

#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

static std::vector<std::uint64_t> load_sequence(const std::string& filename) {
    std::ifstream in(filename.c_str());
    if (!in)
        throw std::runtime_error("No se pudo abrir el archivo: " + filename);

    std::vector<std::uint64_t> sequence;
    std::uint64_t value;
    while (in >> value)
        sequence.push_back(value);

    if (sequence.empty())
        throw std::runtime_error("El archivo no contiene una secuencia de bloques.");
    return sequence;
}

static std::vector<std::uint64_t> generate_sequence(const std::string& pattern,
                                                     std::size_t count) {
    std::vector<std::uint64_t> sequence;
    sequence.reserve(count);
    if (pattern == "ordenada") {
        for (std::size_t i = 0; i < count; ++i)
            sequence.push_back(static_cast<std::uint64_t>(i % 64));
    } else if (pattern == "repetitiva") {
        const std::uint64_t pattern_values[] = {0, 8, 16, 24, 0, 8, 16, 24, 1, 9, 17, 25};
        for (std::size_t i = 0; i < count; ++i)
            sequence.push_back(pattern_values[i % 12]);
    } else if (pattern == "aleatoria") {
        std::mt19937_64 generator(20261016); // Semilla fija para resultados reproducibles.
        std::uniform_int_distribution<std::uint64_t> distribution(0, 63);
        for (std::size_t i = 0; i < count; ++i)
            sequence.push_back(distribution(generator));
    } else {
        throw std::runtime_error("Patron no reconocido. Use ordenada, aleatoria o repetitiva.");
    }
    return sequence;
}

static void print_results(const std::vector<std::uint64_t>& sequence,
                          const std::string& pattern,
                          const std::string& csv_file) {
    const std::size_t capacity = 16;
    const double hit_latency = 1.0;
    const double miss_penalty = 50.0;
    const std::size_t ways_list[] = {1, 2, 4, 8, 16};

    std::ofstream csv(csv_file.c_str());
    if (!csv)
        throw std::runtime_error("No se pudo crear el CSV: " + csv_file);

    csv << "patron,configuracion,capacidad_bloques,vias,accesos,aciertos,fallos,"
           "tasa_aciertos_pct,tasa_fallos_pct,reemplazos,tiempo_modelado_ns\n";

    std::cout << "\nPatron: " << pattern
              << " | Capacidad: " << capacity << " bloques"
              << " | Accesos: " << sequence.size() << "\n";
    std::cout << "Latencias del modelo: hit = " << hit_latency
              << " ns, penalizacion adicional por miss = " << miss_penalty << " ns\n\n";

    std::cout << std::left << std::setw(31) << "Configuracion"
              << std::right << std::setw(10) << "Hits"
              << std::setw(10) << "Misses"
              << std::setw(13) << "Hit ratio"
              << std::setw(13) << "Miss ratio"
              << std::setw(13) << "Reemplazos"
              << std::setw(17) << "Tiempo (ns)" << "\n";
    std::cout << std::string(107, '-') << "\n";

    for (std::size_t i = 0; i < sizeof(ways_list) / sizeof(ways_list[0]); ++i) {
        Cache cache(capacity, ways_list[i], hit_latency, miss_penalty);
        for (std::size_t j = 0; j < sequence.size(); ++j)
            cache.access(sequence[j]);

        const CacheStats& s = cache.stats();
        const double hit_ratio = 100.0 * s.hits / s.accesses;
        const double miss_ratio = 100.0 * s.misses / s.accesses;

        std::cout << std::left << std::setw(31) << cache.configuration_name()
                  << std::right << std::setw(10) << s.hits
                  << std::setw(10) << s.misses
                  << std::setw(12) << std::fixed << std::setprecision(2) << hit_ratio << "%"
                  << std::setw(12) << miss_ratio << "%"
                  << std::setw(13) << s.replacements
                  << std::setw(17) << std::setprecision(2) << s.total_access_time_ns
                  << "\n";

        csv << pattern << ",\"" << cache.configuration_name() << "\","
            << capacity << "," << cache.ways() << "," << s.accesses << ","
            << s.hits << "," << s.misses << ","
            << std::fixed << std::setprecision(4) << hit_ratio << ","
            << miss_ratio << "," << s.replacements << ","
            << std::setprecision(2) << s.total_access_time_ns << "\n";
    }

    std::cout << "\nResultados guardados en: " << csv_file << "\n";
}

int main(int argc, char* argv[]) {
    try {
        std::string pattern = "repetitiva";
        std::string csv_file = "resultados.csv";
        std::vector<std::uint64_t> sequence;

        if (argc >= 2 && std::string(argv[1]) == "--archivo") {
            if (argc < 3)
                throw std::runtime_error("Uso: ./proyecto11 --archivo datos/secuencia.txt [salida.csv]");
            sequence = load_sequence(argv[2]);
            pattern = "archivo:" + std::string(argv[2]);
            if (argc >= 4)
                csv_file = argv[3];
        } else {
            if (argc >= 2)
                pattern = argv[1];
            if (argc >= 3)
                csv_file = argv[2];
            std::size_t count = 256;
            sequence = generate_sequence(pattern, count);
        }

        print_results(sequence, pattern, csv_file);
    } catch (const std::exception& ex) {
        std::cerr << "Error: " << ex.what() << "\n";
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
