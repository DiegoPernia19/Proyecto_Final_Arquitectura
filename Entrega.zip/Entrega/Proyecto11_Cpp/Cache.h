#ifndef CACHE_H
#define CACHE_H

#include <cstddef>
#include <cstdint>
#include <list>
#include <vector>
#include <string>

struct CacheStats {
    std::uint64_t accesses = 0;
    std::uint64_t hits = 0;
    std::uint64_t misses = 0;
    std::uint64_t replacements = 0;
    double total_access_time_ns = 0.0;
};

class Cache {
public:
    // ways == 1: correspondencia directa; ways == capacity_blocks: totalmente asociativa.
    // Otros valores representan caché asociativa por conjuntos.
    Cache(std::size_t capacity_blocks,
          std::size_t ways,
          double hit_latency_ns = 1.0,
          double miss_penalty_ns = 50.0);

    void access(std::uint64_t address);
    const CacheStats& stats() const;
    std::size_t capacity() const;
    std::size_t ways() const;
    std::size_t sets() const;
    std::string configuration_name() const;

private:
    struct Line {
        bool valid = false;
        std::uint64_t block_id = 0;
    };

    std::size_t capacity_blocks_;
    std::size_t ways_;
    std::size_t set_count_;
    double hit_latency_ns_;
    double miss_penalty_ns_;
    std::vector<std::vector<Line> > sets_;
    // Una lista LRU por conjunto: al frente está el bloque usado más recientemente.
    std::vector<std::list<std::uint64_t> > lru_;
    CacheStats stats_;

    std::size_t set_index(std::uint64_t block_id) const;
    void mark_recent(std::size_t set, std::uint64_t block_id);
};

#endif
